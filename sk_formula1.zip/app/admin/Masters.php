<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class Masters extends Model
{
    //
}
