<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class RoleAssign extends Model
{
    //
}
