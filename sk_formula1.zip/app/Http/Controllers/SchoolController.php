<?php

namespace App\Http\Controllers;

use App\School;
use App\Location;
use Illuminate\Http\Request;
use DB;

class SchoolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $eq=School::all();
        return view('admin.school',compact('eq'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // $loc=Location::all();
        // $zone=DB:
        $loc=DB::table('locations')
            ->leftjoin('tbl_state','locations.state','=','tbl_state.id')
            ->leftjoin('tbl_city','locations.city','=','tbl_city.id')
            ->select('locations.*','tbl_state.name as state_name','tbl_city.name as city_name')->get();
        return view("admin.schoolcr",compact('loc'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        
        $r->validate(['school_name'=>'required','type'=>'required','address'=>'required',
            'zone'=>'required',
            'state'=>'required',
            'city'=>'required','annual_fees'=>'numeric|nullable','mobile'=>'numeric|nullable',
            'principal_mobile'=>'numeric|nullable'


            ],['school_name.required'=>'The School/Collage Name field is required','mobile.numeric'=>'The School/Collage Phone field  must be a number.','principal_mobile.numeric'=>'The Principal Phone field  must be a number.']);
        $data=$r->except('_token');
        $aka=School::insert($data);
        if($aka)
            return redirect('school')->with('success','Rrecord Saved.');
        else
            return redirect('school')->withErrors('Unable to save Record.');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function show($v)
    {
        $k=School::find(base64_decode($v));
        return view('admin.schoolv',compact('k'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function edit($v)
    {
        $r=School::find(base64_decode($v));

        $loc=DB::table('locations')
            ->leftjoin('tbl_state','locations.state','=','tbl_state.id')
            ->leftjoin('tbl_city','locations.city','=','tbl_city.id')
            ->select('locations.*','tbl_state.name as state_name','tbl_city.name as city_name')->get();
        return view('admin.schooled',compact('r','loc'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r)
    {
        $up=School::find($r->sid);
        if($up)
        {
            $data=$r->except('_token','sid');
            $ok=School::where('id',$r->sid)
                    ->update($data);
            if($ok)
                return redirect('school')->with('success','Record Updated.');
            else
               return redirect('school')->withErrors('Unable to update Record.'); 
        }
        else
            return redirect('school')->withErrors('Unable to update Record.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\School  $school
     * @return \Illuminate\Http\Response
     */
    public function destroy($v)
    {
        $kk=School::find(base64_decode($v));
        if($kk->delete())
            return redirect('school')->with('success','Record Deleted');
        else
            return redirect('school')->withErrors('Unable to delete record.');
    }
}
