<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dd(Auth::user()->role);
        
        $vw=$this->selector();
        return view('demo',compact('vw'));

        // return view('layouts.admin');
    }
    public function selector()
    {
        $ab=Auth::user()->role;
        // if($ab==1)
        switch($ab){
            case 1:
                return 'admin';
                break;
            case 2:
                return 'coadmin';
                break;
            case 3:
                return 'school';
                break;
            case 4:
                return 'manufacturer';
                break;
            case 5:
                return 'student';
            default:
                return 'null';

        }

    }
}
