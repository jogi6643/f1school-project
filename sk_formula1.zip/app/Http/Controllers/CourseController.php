<?php

namespace App\Http\Controllers;

use App\Course;
use App\DocType;
use App\CourseMaster;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $eq=Course::with('type','csm')->get();
        return view('admin.course',compact('eq'));
        // dd($eq);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $dtype=DocType::all();
        $csm=CourseMaster::all();
        return view('admin.coursecr',compact('dtype','csm'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        $d='';
        $r->validate(['title'=>'required','doc_types_id'=>'required','description'=>'required','course_masters_id'=>'required'],['course_masters_id.required'=>'The Course Name field is required.','doc_types_id.required'=>'The Document type field is required']);
        if($r->doc_types_id==1)
            $r->validate(['doc_path'=>'required']);
        elseif($r->doc_types_id==2)
            $r->validate(['video_path'=>'required']);
        else{
            //
        }
        $data=$r->except('_token');
        if($r->hasFile('doc_path')){            
            $fname=time().".".$r->file('doc_path')->getClientOriginalExtension();
            $pp=public_path('docs/');
            if($r->file('doc_path')->move($pp,$fname))
                $data['doc_path']=$fname;
        }
        
        $d=Course::insert($data);
        if($d)
            return redirect('course')->with('success','Record Saved.');
        else
            return redirect('course')->withErrors('Unable to save record.');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show($v)
    {
        $k=Course::with('type','csm')->find(base64_decode($v));
        return view('admin.coursev',compact('k'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit($v)
    {
        $k=Course::find(base64_decode($v));
        $dtype=DocType::all();
        $csm=CourseMaster::all();
        return view('admin.courseed',compact('k','dtype','csm'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r)
    {
        // dd($r->all());
         $d='';
        $r->validate(['title'=>'required','doc_types_id'=>'required','description'=>'required','course_masters_id'=>'required'],['course_masters_id.required'=>'The Course Name field is required.','doc_types_id.required'=>'The Document type field is required']);
        // if($r->doc_types_id==1)
        //     $r->validate(['doc_path'=>'required']);
        // elseif($r->doc_types_id==2)
        //     $r->validate(['video_path'=>'required']);
        // else{
            //
        // }
        $data=$r->except('_token','cid');
        if($r->hasFile('doc_path')){            
            $fname=time().".".$r->file('doc_path')->getClientOriginalExtension();
            $pp=public_path('docs/');
            if($r->file('doc_path')->move($pp,$fname))
                $data['doc_path']=$fname;
        }
        if($r->video_path)
            $data['doc_path']='';
        
        $d=Course::where('id',$r->cid)->update($data);
        if($d)
            return redirect('course')->with('success','Record Saved.');
        else
            return redirect('course')->withErrors('Unable to save record.');
        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy($v)
    {
        $pk=Course::find(base64_decode($v));
        if($pk->delete())
            return redirect('course')->with('success','Record Deleted.');
        else
            return redirect('course')->withErrors('Unable to delete Record.');
    }
    public function getbycs($v)
    {
        $eq=Course::with('csm','type')->where('course_masters_id',base64_decode($v))->get();
        return view('admin.course',compact('eq'));
    }
}
