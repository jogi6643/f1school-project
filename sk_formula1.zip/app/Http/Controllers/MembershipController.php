<?php

namespace App\Http\Controllers;

use App\Membership;
use App\Course;
use Illuminate\Http\Request;

class MembershipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $eq=Membership::all();
        //dd($eq);
        foreach($eq as $k=>$q){

            $l1=explode(",",$q->course_list);
            
            $cn=Course::whereIn('id',$l1)->select('title')->get()->toArray();
            
            
            $res = implode(",", array_column($cn, 'title'));
            $eq[$k]->course_list = $res;
            //$a=array($q,'res'=>$res);
            //dd($a);
            //$asd= $res);
            // dd($res);
            //print_r(in_array("title",$cn));
            // print_r($asd);
            // dd($cn);
            //$eq['courses']=$res;
        }
        return view('admin.membership',compact('eq'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cs=Course::with('type','csm')->get();
        // dd($cs);
        return view('admin.membershipcr',compact('cs'));
    }

    public function activitysrch($v)
    {
        echo $v;
        // $nv=
        $ab=Course::where('title','like','%'.$v.'%')->get();

        return view('datas.courselist',compact('ab'));
        // dd($ab);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        $ab=implode(",",$r->courselist);

        $mb=new Membership();
        $mb->name=$r->name;
        $mb->fee_per_student=$r->fee_per_student;
        $mb->course_list=$ab;
        if($mb->save())
            return redirect('membership')->with('success','Record Saved.');
        else
            return redirect('membership')->withErrors('Unable to save record.');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Membership  $membership
     * @return \Illuminate\Http\Response
     */
    public function show(Membership $membership)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Membership  $membership
     * @return \Illuminate\Http\Response
     */
    public function edit($v)
    {
        $k=Membership::find(base64_decode($v));
        $cs=Course::with('type','csm')->get();
        if($v)
        return view('admin.membershiped',compact('k','cs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Membership  $membership
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r)
    {
        dd($r->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Membership  $membership
     * @return \Illuminate\Http\Response
     */
    public function destroy($v)
    {
        $ar=Membership::find(base64_decode($v));
        if($ar)
            if($ar->delete())
                return redirect('membership')->with('success','Record deleted.');
            
                return redirect('membership')->withErrors('Unable to delete record.');
    }
}
