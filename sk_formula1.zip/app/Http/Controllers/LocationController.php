<?php

namespace App\Http\Controllers;

use App\Location;
use App\States;
use App\City;
use DB;
use Illuminate\Http\Request;
use Illuminate\Database\QueryException;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $eq=Location::all();
        $eq=DB::table('locations')
            ->leftjoin('tbl_state','locations.state','=','tbl_state.id')
            ->leftjoin('tbl_city','locations.city','=','tbl_city.id')
            ->select('locations.*','tbl_state.name as state_name','tbl_city.name as city_name')->get();
        // dd($eq);
        return view('admin.location',compact('eq'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $loc=States::all();
        // dd($st);
        return view('admin.locationed',compact('loc'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        try{
        // dd($req->all());
        $req->validate(['zone'=>'required','state'=>'required','city'=>'required','status'=>'required']);
        $data=$req->except('_token');
        $ab=Location::insert($data);
        if($ab)
            return redirect('location')->with('success','Record Saved.');
        else
            return redirect('location')->withErrors('Record Saved.');
        }catch (QueryException $e){
                  $error_code = $e->errorInfo[1];
                
       if($error_code == 1062){
             \LogActivity::addToLog('Try to insert duplicate Zone Name');
            //activity()->log('Label Creation faild due to duplicacy');
          // self::delete($lid);
    
            $req->session()->flash('status', 'Zone name can not be duplicate');
             }
              //return redirect('tms_training');
             }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function show($v)
    {
        $k=Location::find(base64_decode($v));
        return view('admin.locationv',compact('k'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function edit($v)
    {
        
        // $lp=Location::find(base64_decode($v));
        $lp=DB::table('locations')
            ->leftjoin('tbl_state','locations.state','=','tbl_state.id')
            ->leftjoin('tbl_city','locations.city','=','tbl_city.id')
            ->where('locations.id','=',base64_decode($v))
            ->select('locations.*','tbl_state.name as state_name','tbl_city.name as city_name')->first();
// dd($lp);
        $loc=States::all();
        if($lp)
        return view('admin.locationed2',compact('lp','loc'));
        else
            return redirect('location')->withErrors('Request record not found.');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r)
    {
        try{
        $up=Location::find($r->lid);
        if($up){
            $up->zone=$r->zone;
            $up->state=$r->state;
            $up->city=$r->city;
            $up->status=$r->status;
            $up->save();
            if($up->wasChanged())
                return redirect('location')->with('success','Record updated.');
            else
                return redirect('location')->withErrors('Unable to update record.');

        }
        else
        {
            return redirect()->back()->withErrors("Unable to update record.");
        }
        }catch (QueryException $e){
                  $error_code = $e->errorInfo[1];
                
       if($error_code == 1062){
             \LogActivity::addToLog('Try to insert duplicate Zone Name');
            //activity()->log('Label Creation faild due to duplicacy');
          // self::delete($lid);
    
            $req->session()->flash('status', 'Zone name can not be duplicate');
             }
              //return redirect('tms_training');
             }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function destroy($v)
    {
        $sd=Location::find(base64_decode($v));
        if($sd->delete())
            return redirect('location')->with('success','Record deleted.');
        else
            return redirect('location')->withErrors('Unable to delete record.');
    }

    public function getcitylist($v)
    {
        $city=City::where('state_id',base64_decode($v))->get();
        return view('datas.city',compact('city'));
    }
    public function locationbyzone($v)
    {
        $ab=DB::table('locations')
            ->leftjoin('tbl_state','locations.state','=','tbl_state.id')
            ->leftjoin('tbl_city','locations.city','=','tbl_city.id')
            ->where('locations.id','=',base64_decode($v))->select('locations.*','tbl_state.name as state_name','tbl_city.name as city_name')->first();
            // dd($ab);
            $res="<option value='".$ab->state."'>".$ab->state_name."</option>,<option value='".$ab->city."'>".$ab->city_name."</option>";
            return $res;
    }
}
