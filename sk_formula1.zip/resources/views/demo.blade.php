@extends('layouts.'.$vw)


@section('content')

	{{$vw}}

@endsection