 @extends('layouts.admin')
 @section('content')
            <div class="content-heading">
               <div>Location Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="{{url('agentreg')}}" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div class="alert alert-info">{{session()->get('success')}}</div>
            @endif
   <div class="col-md-12">
         <form method="post" action="">
            @csrf
            <div class="form-group">
               <label>Zone</label>
               <input type="text" name="zone" class="form-control" value="{{old('zone')}}">
            </div>
            <div class="form-group">
               <label>State</label>
               <!-- <input type="text" name="state" class="form-control" value="{{old('state')}}"> -->
               <select name="state" class="form-control" id='udpcityid'>
                  <option value="" selected="">Select Any</option>
                  @if(count($loc)>0)
                     @foreach($loc as $lc) 
                        @if($lc->id==old('state'))
                           <option value="{{$lc->id}}" selected="">{{$lc->name}}</option>
                        @else
                           <option value="{{$lc->id}}">{{$lc->name}}</option>
                        @endif
                     @endforeach


                  @endif
               </select>
            </div>
            <div class="form-group">
               <label>City</label>
               <!-- <input type="text" name="city" class="form-control" value="{{old('city')}}"> -->
               <select name="city" class="form-control" id='udpcitylist'>
                  <option value="" selected="">Select Any</option>
                  
               </select>
            </div>
            <div class="form-group">
               <label>Status</label>
               <select name="status" class="form-control">
                  
                  <option value="0" {{old('status')?'':'selected'}}>Inactive</option>
                  <option value="1" {{old('status')?'selected':''}} >Active</option>
               </select>
            </div>
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
@endsection

@section('footer')
<script type="text/javascript">
   $(document).ready(function() {
      $('#udpcityid').change(function(){
         var v=$('#udpcityid').val();
         
         var nurl="{{url('getcitylist')}}/"+btoa(v);
         // alert('ok'+v + " amb " + nurl);
          $.get(nurl,function(data,status){
            // alert("res= "+data);
            $('#udpcitylist').html(data);
          })
      });
   });
</script>

@endsection