 @extends('layouts.admin')
 @section('content')
            <div class="content-heading">
               <div>Location Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="{{url('agentreg')}}" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div class="alert alert-info">{{session()->get('success')}}</div>
            @endif
   <div class="col-md-12">
         <form method="post" action="{{url('membershiped')}}">
            @csrf
            <div class="form-group">
               <label>Membership Name</label>
               <input type="text" name="name" class="form-control" value="{{old('name')}}">
            </div>
            <div class="form-group">
               <label>Fee per Student</label>
               <input type="text" name="fee_per_student" class="form-control" value="{{old('fee_per_student')}}">
            </div>
            <div class="form-group">
               <label>Activity List </label> <!-- <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal">Add Course</button> -->
               <!-- <input type="text" name="search_activity" id="activityid"> -->
               
               
            </div>
            <div class="row">
               <!-- <div class="col-md-3" id='courselistid'> asdf</div>  -->
               <div class="col-md-12" style="max-height: 300px; overflow-y: auto;">
                  <div class="row">
                  @foreach($cs as $k=> $c)
                     <div class="col-md-4">
                        <input type="checkbox" name="courselist[]" value="{{$c->id}}"> {{$k+1}}. {{$c->title}} ({{isset($c->type->type)?$c->type->type:''}}) 
                     </div>
                      
 
                  @endforeach
                  <!-- <div class="col-md-4 offset-md-8"><button type="button" class="btn btn-success" id="applybtnid">Apply</button></div> -->
                  </div>
               </div>
            </div>
            <br>
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
@endsection

