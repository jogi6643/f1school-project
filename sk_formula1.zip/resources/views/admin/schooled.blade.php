 @extends('layouts.admin')
 @section('content')
            <div class="content-heading">
               <div>School Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="{{url('agentreg')}}" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div class="alert alert-info">{{session()->get('success')}}</div>
            @endif
   <div class="col-md-10 offset-md-1">
         <form method="post" action="{{url('schooled')}}">
            @csrf
            
            <div class="form-group">
               <label>School/College Name</label>
               <input type="text" name="school_name" class="form-control" value="{{old('school_name')?old('school_name'):$r->school_name}}">
               <input type="hidden" name="sid" class="form-control" value="{{old('sid')?old('sid'):$r->id}}">
            </div>
            <div class="form-group">
               <label>Annual Fee</label>
               <input type="text" name="annual_fees" class="form-control" value="{{old('annual_fees')?old('annual_fees'):$r->annual_fees}}">
            </div>
            <div class="form-group">
               <label>Type</label>
               <select name="type" class="form-control">
                  @if(old('type')) <option value="{{old('type')}}" selected>{!!ucfirst(old('type'))!!} </option> 
                  @else
                     <option value="{{$r->type}}" selected>{!!ucfirst($r->type)!!} </option> 
                  @endif
                  <option value="school">School</option>
                  <option value="college">College</option>
               </select>
            </div>

            <!-- <div class="form-group">
               <label>Annual Fee</label>
               <input type="text" name="annual_fees" class="form-control" value="{{old('annual_fees')}}">
            </div> -->
            <div class="form-group">
               <label>Status</label>
               <select name="status" class="form-control">
                  @if(old('type')) <option value="{{old('status')}}" selected>{{old('status')?'Active':'Inactive'}} </option> 
                  @else
                     <option value="{{$r->status}}" selected>{{$r->status?'Active':'Inactive'}} </option> 
                  @endif
                  <option value="0">Inactive</option>
                  <option value="1">Active</option>
               </select>
            </div>
            <div class="form-group">
               <label>Address</label>
               <input type="text" name="address" class="form-control" value="{{old('address')?old('address'):$r->address}}">
            </div>
            <div class="form-group">
               <label>Zone</label>
               <!-- <input type="text" name="zone" class="form-control" value="{{old('zone')?old('zone'):$r->zone}}"> -->
                <select name="zone" class="form-control" id='zonecalid'>
                  <option value="" selected="">Select Any</option>
                  @if(count($loc)>0)
                     @foreach($loc as $lc) 
                        @if($lc->zone==old('zone'))
                           <option value="{{$lc->id}}" selected="">{{$lc->zone." - ".$lc->state_name." - ".$lc->city_name}}</option>
                        @else
                           <option value="{{$lc->id}}">{{$lc->zone." - ".$lc->state_name." - ".$lc->city_name}}</option>
                        @endif
                     @endforeach


                  @endif
               </select>
            </div>
            <div class="form-group">
               <label>State</label>
               <!-- <input type="text" name="state" class="form-control" value="{{old('state')?old('state'):$r->state}}"> -->
               <select name="state" class="form-control" id="stateid">
                  
               </select>
            </div>
            <div class="form-group">
               <label>City</label>
               <!-- <input type="text" name="city" class="form-control" value="{{old('city')?old('city'):$r->city}}"> -->
               <select name="state" class="form-control" id="cityid">
                  
               </select>
            </div>
            <div class="form-group">
               <label>Website</label>
               <input type="text" name="website" class="form-control" value="{{old('website')?old('website'):$r->website}}">
            </div>
            <div class="form-group">
               <label>Email ID</label>
               <input type="email" name="email" class="form-control" value="{{old('email')?old('email'):$r->email}}">
            </div>
            <div class="form-group">
               <label>Phone No.</label>
               <input type="text" name="mobile" class="form-control" value="{{old('mobile')?old('mobile'):$r->mobile}}">
            </div>
            <div class="form-group">
               <label>Principal Name</label>
               <input type="text" name="principal_name" class="form-control" value="{{old('principal_name')?old('principal_name'):$r->principal_name}}">
            </div>
            <div class="form-group">
               <label>Principal Mobile</label>
               <input type="text" name="principal_mobile" class="form-control" value="{{old('principal_mobile')?old('principal_mobile'):$r->principal_mobile}}">
            </div>
            <div class="form-group">
               <label>Principal Email</label>
               <input type="email" name="principal_email" class="form-control" value="{{old('principal_email')?old('principal_email'):$r->principal_email}}">
            </div>




            
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
@endsection


@section('footer')
<script type="text/javascript">
   $(document).ready(function() {
      $('#zonecalid').change(function(){
         var v=$('#zonecalid').val();
         
         var nurl="{{url('locationbyzone')}}/"+btoa(v);
         // alert('ok'+v + " amb " + nurl);
          $.get(nurl,function(data,status){
            // alert("res= "+data);
            var abc=data.split(",");
            $('#stateid').html(abc[0]);
            $('#cityid').html(abc[1]);
            // $('#udpcitylist').html(data);
          })
      });
   });
</script>

@endsection