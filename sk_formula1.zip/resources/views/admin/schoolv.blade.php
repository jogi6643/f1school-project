@extends('layouts.admin')
@section('content')
 
             <div class="content-heading">
               <div>School Details
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               
            </div>

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div class="alert alert-info">{{session()->get('success')}}</div>
            @endif
 <table class="table table-hover table-striped">
 	<thead>
 		<tr>
         <th width="25%">School Name</th> <td> {{$k->school_name}}</td>
      </tr>
   </thead>
   <tbody>
      <tr>
 			<th>#</th><td>{{$k->id}}</td>
      </tr>
      <tr>
            <th>Annual Fees</th><td>{{$k->annual_fees}}</td>
         </tr>
      <tr>
         
            <th>Address</th><td>{{$k->address}}</td>
         </tr>
         <tr>
 			<th>Zone</th><td> {{$k->zone}}</td>
         </tr>
         <tr>
 			<th>State</th><td>{{$k->state}} </td>
         </tr>
         <tr>
 			<th>City</th><td>{{$k->city}} </td>
         </tr>
         
         
         <tr>
            <th>Website</th><td>{{$k->website}}</td>
         </tr>
         <tr>
            <th>Mobile</th><td>{{$k->mobile}}</td>
         </tr>
         <tr>
            <th>Email</th><td>{{$k->email}}</td>
         </tr>
         
         <tr>
            <th>Principal Name</th><td>{{$k->principal_name}}</td>
         </tr>
         <tr>
            <th>Principal Mobile</th><td>{{$k->principal_mobile}}</td>
         </tr>
         <tr>
            <th>Principal Email</th><td>{{$k->principal_email}}</td>
         </tr>
         <tr>
            <th>Status</th><td>{{$k->status}}</td>
         </tr>
         <tr>
         <th>Created At</th><td>{{$k->created_at}} </td>
         </tr>
         <tr>
            <th>Updated At</th><td>{{$k->updated_at}}</td>
         </tr>
 		
 	
      
 	</tbody>
 </table>






@endsection



