@if(count($city)>0)
	@foreach($city as $c)
		<option value="{{$c->id}}">{{$c->name}}</option>

	@endforeach
@endif