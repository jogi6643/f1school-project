<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});
Route::group(['middleware'=>'Chkdemo'],function(){
Auth::routes();
Auth::routes(['register'=>false]);




	Route::group(['middleware'=>'auth'],function(){
		Route::get('/home', 'HomeController@index')->name('home');
		Route::get('/abc','SelectorController@getview');

		Route::get('getcitylist/{id}','LocationController@getcitylist');
		Route::get('location','LocationController@index');
		Route::get('locationcr','LocationController@create');
		Route::post('locationcr','LocationController@store');
		Route::get('locationed/{id}','LocationController@edit');
		Route::post('locationed','LocationController@update');
		Route::get('locationdel/{id}','LocationController@destroy');
		Route::get('locationv/{id}','LocationController@show');
		Route::get('locationbyzone/{id}','LocationController@locationbyzone');

		Route::get('school','SchoolController@index');
		Route::get('schoolv/{id}','SchoolController@show');
		Route::get('schoolcr','SchoolController@create');
		Route::post('schoolcr','SchoolController@store');
		Route::get('schooled/{id}','SchoolController@edit');
		Route::post('schooled','SchoolController@update');
		Route::get('schooldel/{id}','SchoolController@destroy');


		Route::get('competition','CompetitionController@index');

		Route::get('course','CourseController@index');
		Route::get('coursev/{id}','CourseController@show');
		Route::get('coursecr','CourseController@create');
		Route::post('coursecr','CourseController@store');
		Route::get('coursedel/{id}','CourseController@destroy');
		Route::get('courseed/{id}','CourseController@edit');
		Route::post('courseed','CourseController@update');
		Route::get('coursecs/{id}','CourseController@getbycs');

		Route::get('coursename','CourseMasterController@index');
		Route::get('coursenamecr','CourseMasterController@create');
		Route::post('coursenamecr','CourseMasterController@store');
		Route::get('coursenameed/{id}','CourseMasterController@edit');
		Route::post('coursenameed','CourseMasterController@update');
		Route::get('coursenamedel/{id}','CourseMasterController@destroy');


		Route::get('membership','MembershipController@index');
		Route::get('membershipcr','MembershipController@create');
		Route::post('membershipcr','MembershipController@store');
		Route::get('membershiped/{id}','MembershipController@edit');
		Route::post('membershiped','MembershipController@update');
		Route::get('membershipdel/{id}','MembershipController@destroy');
		Route::get('activitysrch/{id}','MembershipController@activitysrch');
		
	});

});

