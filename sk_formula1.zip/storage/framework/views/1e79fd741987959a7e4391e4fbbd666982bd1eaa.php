 
 <?php $__env->startSection('content'); ?>
            <div class="content-heading">
               <div>Course Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="<?php echo e(url('agentreg')); ?>" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
   <div class="col-md-12">
         <form method="post" action="" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <label>Course Name</label>
               <select name="course_masters_id" class="form-control" >
                  <option value="" selected="">Select any</option>
                  <?php $__currentLoopData = $csm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($dk->id==old('course_masters_id')): ?>
                  <option value="<?php echo e($dk->id); ?>" selected=""><?php echo e($dk->course_name); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($dk->id); ?>"><?php echo e($dk->course_name); ?></option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
               </select>
            </div>
            <div class="form-group">
               <label>Title</label>
               <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>">
            </div>
            <div class="form-group">
               <label>Type</label>
               <select name="doc_types_id" class="form-control" id='doctypeid'>
                  <option value="" selected="">Select any</option>
                  <?php $__currentLoopData = $dtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($dk->id==old('doc_types_id')): ?>
                  <option value="<?php echo e($dk->id); ?>" selected=""><?php echo e($dk->type); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($dk->id); ?>"><?php echo e($dk->type); ?></option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
               </select>
            </div>
             <div class="form-group">
               <label>Description</label>
               <textarea name="description" class="form-control" ><?php echo e(old('description')); ?></textarea>
               
            </div>
             <div class="form-group">
               <label>Duration</label>
               <input type="time" name="duration" class="form-control" value="<?php echo e(old('duration')); ?>">
            </div>
            <div class="form-group" id="videopathid" style="display: none;">
               <label>Video Path</label>
               <input type="text" name="video_path" class="form-control" id="videopathid2" value="<?php echo e(old('video_path')); ?>">
            </div>
            <div class="form-group" id="docpathid">
               <label>Document</label>
               <input type="file" name="doc_path" class="form-control" id="docpathid2" value="<?php echo e(old('doc_path')); ?>">
            </div>
            
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
   <script type="text/javascript">
      $(document).ready(function(){
         $('#doctypeid').change(function(){
            
            if($('#doctypeid').val()==1){
               $('#videopathid2').val('');
               $('#videopathid').hide();

               $('#docpathid').show();
            }
            else if($('#doctypeid').val()==2){
               $('#docpathid').hide();
               $('#videopathid').show();
               $('#docpathid2').val('');
            }
            else
            {
               $('#docpathid').hide();
               $('#videopathid').hide();
            }
         });
         if($('#doctypeid').val()==1){
               $('#videopathid2').val('');
               $('#videopathid').hide();

               $('#docpathid').show();
            }
            else if($('#doctypeid').val()==2){
               $('#docpathid').hide();
               $('#videopathid').show();
               $('#docpathid2').val('');
            }
            else
            {
               $('#docpathid').hide();
               $('#videopathid').hide();
            }

      });
   </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>