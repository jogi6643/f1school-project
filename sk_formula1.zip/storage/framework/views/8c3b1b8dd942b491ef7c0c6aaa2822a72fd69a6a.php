<?php $__env->startSection('content'); ?>
 
             <div class="content-heading">
               <div>School Details
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
 <table class="table table-hover table-striped">
 	<thead>
 		<tr>
         <th width="25%">School Name</th> <td> <?php echo e($k->school_name); ?></td>
      </tr>
   </thead>
   <tbody>
      <tr>
 			<th>#</th><td><?php echo e($k->id); ?></td>
      </tr>
      <tr>
            <th>Annual Fees</th><td><?php echo e($k->annual_fees); ?></td>
         </tr>
      <tr>
         
            <th>Address</th><td><?php echo e($k->address); ?></td>
         </tr>
         <tr>
 			<th>Zone</th><td> <?php echo e($k->zone); ?></td>
         </tr>
         <tr>
 			<th>State</th><td><?php echo e($k->state); ?> </td>
         </tr>
         <tr>
 			<th>City</th><td><?php echo e($k->city); ?> </td>
         </tr>
         
         
         <tr>
            <th>Website</th><td><?php echo e($k->website); ?></td>
         </tr>
         <tr>
            <th>Mobile</th><td><?php echo e($k->mobile); ?></td>
         </tr>
         <tr>
            <th>Email</th><td><?php echo e($k->email); ?></td>
         </tr>
         
         <tr>
            <th>Principal Name</th><td><?php echo e($k->principal_name); ?></td>
         </tr>
         <tr>
            <th>Principal Mobile</th><td><?php echo e($k->principal_mobile); ?></td>
         </tr>
         <tr>
            <th>Principal Email</th><td><?php echo e($k->principal_email); ?></td>
         </tr>
         <tr>
            <th>Status</th><td><?php echo e($k->status); ?></td>
         </tr>
         <tr>
         <th>Created At</th><td><?php echo e($k->created_at); ?> </td>
         </tr>
         <tr>
            <th>Updated At</th><td><?php echo e($k->updated_at); ?></td>
         </tr>
 		
 	
      
 	</tbody>
 </table>






<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>