 
 <?php $__env->startSection('content'); ?>
            <div class="content-heading">
               <div>Location Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="<?php echo e(url('agentreg')); ?>" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
   <div class="col-md-12">
         <form method="post" action="">
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <label>Zone</label>
               <input type="text" name="zone" class="form-control" value="<?php echo e(old('zone')); ?>">
            </div>
            <div class="form-group">
               <label>State</label>
               <!-- <input type="text" name="state" class="form-control" value="<?php echo e(old('state')); ?>"> -->
               <select name="state" class="form-control" id='udpcityid'>
                  <option value="" selected="">Select Any</option>
                  <?php if(count($loc)>0): ?>
                     <?php $__currentLoopData = $loc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if($lc->id==old('state')): ?>
                           <option value="<?php echo e($lc->id); ?>" selected=""><?php echo e($lc->name); ?></option>
                        <?php else: ?>
                           <option value="<?php echo e($lc->id); ?>"><?php echo e($lc->name); ?></option>
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  <?php endif; ?>
               </select>
            </div>
            <div class="form-group">
               <label>City</label>
               <!-- <input type="text" name="city" class="form-control" value="<?php echo e(old('city')); ?>"> -->
               <select name="city" class="form-control" id='udpcitylist'>
                  <option value="" selected="">Select Any</option>
                  
               </select>
            </div>
            <div class="form-group">
               <label>Status</label>
               <select name="status" class="form-control">
                  
                  <option value="0" <?php echo e(old('status')?'':'selected'); ?>>Inactive</option>
                  <option value="1" <?php echo e(old('status')?'selected':''); ?> >Active</option>
               </select>
            </div>
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
   $(document).ready(function() {
      $('#udpcityid').change(function(){
         var v=$('#udpcityid').val();
         
         var nurl="<?php echo e(url('getcitylist')); ?>/"+btoa(v);
         // alert('ok'+v + " amb " + nurl);
          $.get(nurl,function(data,status){
            // alert("res= "+data);
            $('#udpcitylist').html(data);
          })
      });
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>