<?php $__env->startSection('content'); ?>
 
             <div class="content-heading">
               <div>Location Master
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <div class="ml-auto">
                  <div class="btn-group">
                     <a href="<?php echo e(url('locationcr')); ?>" class="btn btn-warning">Create</a>
                     <!-- <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div> -->
                  </div>
               </div>
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
 <table class="table table-hover table-striped" id="userlistid">
 	<thead>
 		<tr>
 			<th>#</th>
 			<th>Zone</th>
 			<th>State</th>
 			<th>City</th>
 			<th>Status</th>
         <th>Created At</th>
         <th></th>
 		</tr>
 	</thead>
 	<tbody>
      <?php if(count($eq)>0): ?>
 		<?php $__currentLoopData = $eq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($k->id); ?></td> 
			<td><a href="<?php echo e(url('locationv/'.base64_encode($k->id))); ?>" target="__blank"> <?php echo e($k->zone); ?></a></td>
         <td><?php echo e($k->state_name); ?> </td>
         <td><?php echo e($k->city_name); ?> </td>
         <td><?php echo e($k->status); ?> </td>
         
			<td><?php echo e($k->created_at); ?> </td>
         <td> <a href="<?php echo e(url('locationed').'/'.base64_encode($k->id)); ?>" class="btn btn-sm btn-outline-success"><i class="fa fa-edit"></i> </a> <button class="btn btn-sm btn-outline-danger" id="tempdelid-<?php echo e($k->id); ?>" onclick="myfuntemp(this)"><i class="fa fa-trash"></i> </button> </td>
			
			
		 			
		</tr>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 		<?php else: ?>
         No Record Found.....
      <?php endif; ?>
 	</tbody>
 </table>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
 <script type="text/javascript">
 	$(document).ready(function(){
 		$('#userlistid').DataTable();
 	});

   function myfuntemp(arg) {
      var ad=$(arg).attr('id');
      var ak=ad.split('-');
      // alert('val = '+ak[1]);
      if(confirm("Do you really want to delete this."))
         window.location.href='<?php echo e(url("/locationdel")); ?>/'+btoa(ak[1]);
         // alert("yes");
   }
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>