<?php $__env->startSection('content'); ?>
 
             <div class="content-heading">
               <div>Course 
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
            <div class="row">
            	<div class="col-md-4 offset-md-4">
            		<form method="post" action="<?php echo e(url('coursenameed')); ?> ">
            			<?php echo csrf_field(); ?>
            			<div class="form-group">
            				<label>Course Name</label>	
            				<input type="text" name="course_name" value="<?php echo e(old('course_name')?old('course_name'):$k->course_name); ?>">
            				<input type="hidden" name="cid" value="<?php echo e(old('cid')?old('cid'):$k->id); ?>">
            			</div>
            			<div class="text-center">
            				<button type="submit" class="btn btn-success">Save</button>
            			</div>
            		</form>
            	</div>
            </div>


<?php $__env->stopSection(); ?>            
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>