 
 <?php $__env->startSection('content'); ?>
            <div class="content-heading">
               <div>Location Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="<?php echo e(url('agentreg')); ?>" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
   <div class="col-md-12">
         <form method="post" action="">
            <?php echo csrf_field(); ?>
            <div class="form-group">
               <label>Membership Name</label>
               <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
            </div>
            <div class="form-group">
               <label>Fee per Student</label>
               <input type="text" name="fee_per_student" class="form-control" value="<?php echo e(old('fee_per_student')); ?>">
            </div>
            <div class="form-group">
               <label>Activity List </label> <!-- <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal">Add Course</button> -->
               <!-- <input type="text" name="search_activity" id="activityid"> -->
               
               
            </div>
            <div class="row">
               <!-- <div class="col-md-3" id='courselistid'> asdf</div>  -->
               <div class="col-md-12" style="max-height: 300px; overflow-y: auto;">
                  <div class="row">
                  <?php $__currentLoopData = $cs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-4">
                        <input type="checkbox" name="courselist[]" value="<?php echo e($c->id); ?>"> <?php echo e($k+1); ?>. <?php echo e($c->title); ?> (<?php echo e(isset($c->type->type)?$c->type->type:''); ?>) 
                     </div>
                      
 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!-- <div class="col-md-4 offset-md-8"><button type="button" class="btn btn-success" id="applybtnid">Apply</button></div> -->
                  </div>
               </div>
            </div>
            <br>
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>