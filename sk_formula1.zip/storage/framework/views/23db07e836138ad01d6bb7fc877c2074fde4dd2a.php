 
 <?php $__env->startSection('content'); ?>
            <div class="content-heading">
               <div>School Entry
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="<?php echo e(url('agentreg')); ?>" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            <?php if($errors->any()): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($err); ?></div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
               <div class="alert alert-info"><?php echo e(session()->get('success')); ?></div>
            <?php endif; ?>
   <div class="col-md-10 offset-md-1">
         <form method="post" action="<?php echo e(url('schooled')); ?>">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
               <label>School/College Name</label>
               <input type="text" name="school_name" class="form-control" value="<?php echo e(old('school_name')?old('school_name'):$r->school_name); ?>">
               <input type="hidden" name="sid" class="form-control" value="<?php echo e(old('sid')?old('sid'):$r->id); ?>">
            </div>
            <div class="form-group">
               <label>Annual Fee</label>
               <input type="text" name="annual_fees" class="form-control" value="<?php echo e(old('annual_fees')?old('annual_fees'):$r->annual_fees); ?>">
            </div>
            <div class="form-group">
               <label>Type</label>
               <select name="type" class="form-control">
                  <?php if(old('type')): ?> <option value="<?php echo e(old('type')); ?>" selected><?php echo ucfirst(old('type')); ?> </option> 
                  <?php else: ?>
                     <option value="<?php echo e($r->type); ?>" selected><?php echo ucfirst($r->type); ?> </option> 
                  <?php endif; ?>
                  <option value="school">School</option>
                  <option value="college">College</option>
               </select>
            </div>

            <!-- <div class="form-group">
               <label>Annual Fee</label>
               <input type="text" name="annual_fees" class="form-control" value="<?php echo e(old('annual_fees')); ?>">
            </div> -->
            <div class="form-group">
               <label>Status</label>
               <select name="status" class="form-control">
                  <?php if(old('type')): ?> <option value="<?php echo e(old('status')); ?>" selected><?php echo e(old('status')?'Active':'Inactive'); ?> </option> 
                  <?php else: ?>
                     <option value="<?php echo e($r->status); ?>" selected><?php echo e($r->status?'Active':'Inactive'); ?> </option> 
                  <?php endif; ?>
                  <option value="0">Inactive</option>
                  <option value="1">Active</option>
               </select>
            </div>
            <div class="form-group">
               <label>Address</label>
               <input type="text" name="address" class="form-control" value="<?php echo e(old('address')?old('address'):$r->address); ?>">
            </div>
            <div class="form-group">
               <label>Zone</label>
               <input type="text" name="zone" class="form-control" value="<?php echo e(old('zone')?old('zone'):$r->zone); ?>">
            </div>
            <div class="form-group">
               <label>State</label>
               <input type="text" name="state" class="form-control" value="<?php echo e(old('state')?old('state'):$r->state); ?>">
            </div>
            <div class="form-group">
               <label>City</label>
               <input type="text" name="city" class="form-control" value="<?php echo e(old('city')?old('city'):$r->city); ?>">
            </div>
            <div class="form-group">
               <label>Website</label>
               <input type="text" name="website" class="form-control" value="<?php echo e(old('website')?old('website'):$r->website); ?>">
            </div>
            <div class="form-group">
               <label>Email ID</label>
               <input type="email" name="email" class="form-control" value="<?php echo e(old('email')?old('email'):$r->email); ?>">
            </div>
            <div class="form-group">
               <label>Phone No.</label>
               <input type="text" name="mobile" class="form-control" value="<?php echo e(old('mobile')?old('mobile'):$r->mobile); ?>">
            </div>
            <div class="form-group">
               <label>Principal Name</label>
               <input type="text" name="principal_name" class="form-control" value="<?php echo e(old('principal_name')?old('principal_name'):$r->principal_name); ?>">
            </div>
            <div class="form-group">
               <label>Principal Mobile</label>
               <input type="text" name="principal_mobile" class="form-control" value="<?php echo e(old('principal_mobile')?old('principal_mobile'):$r->principal_mobile); ?>">
            </div>
            <div class="form-group">
               <label>Principal Email</label>
               <input type="email" name="principal_email" class="form-control" value="<?php echo e(old('principal_email')?old('principal_email'):$r->principal_email); ?>">
            </div>




            
            <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button> </div>
         </form>
      
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>