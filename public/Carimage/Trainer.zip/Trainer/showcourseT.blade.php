 @extends('layouts.school')
 @section('content')
            <div class="content-heading">
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <h2>{{$k}}</h2>
              
              @include('sweet::alert')
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="{{url('agentreg')}}" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>
            

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div hidden class="alert alert-info">{{session()->get('success')}}</div>
            @endif

       <div class="col-md-12">
           
           <div class="text-right">
                           
                           <button type="button" onclick="goBack()" class="btn btn-info">Go Back</button>

<script>
function goBack() {
  window.history.back();
}
</script>
               </div>
 <h3>{{$planname}}</h3>
               <h5>Course List</h>

   </div>
  
   <br/>
   <div class="col-md-12">
         @if($currentyear==$exyr)
      <form method="post" action="{{url('intimation')}}">
           {{ csrf_field() }}
           
         
    <table class="table table-striped table-bordered" id="courselistid">
 	<thead>
 		<tr>
 		   
 			<th>#</th>
         
 			<th>Course Name</th>
 			<th>Type</th>
 			<th>Assigned Date   <button type="submit"  class="btn btn-primary">Intimation</button></th>

 	
         
 		</tr>
 	</thead>
 	<tbody>
 	   
 	    <?php $i=1?>
 	     @if(count($Course)>0)
 		@foreach($Course as $key=>$Course1)
		<tr>
		 <td>{{$i}}</td>
		 <td id="courseid".{{$Course1->course_masters_id}}>{{$Course1->course_name}}<input hidden type="text" value="{{ $schoolid}}_{{ $planidd}}_{{$acyear}}__{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}"></td> 
         <td id="doctype".{{$Course1->doc_types_id}}>{{$Course1->type}}</td>
          <td id="bday".{{$Course1->doc_types_id}}><input  type="date" name="data_{{ $schoolid}}_{{ $planidd}}_{{$acyear}}_{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}" value="{{ $schoolid}}_{{ $planidd}}_{{$acyear}}_{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}"></td>
		</tr>
		<?php $i++?>
		@endforeach
 		@else
         No Record Found.....
      @endif
     
 	</tbody>
 	
 </table>
 </form>
 
  @else
  
       <form method="post" action="{{url('intimation')}}">
           {{ csrf_field() }}
           
         
    <table class="table table-striped table-bordered" id="courselistid">
 	<thead>
 		<tr>
 		   
 			<th>#</th>
         
 			<th>Course Name</th>
 			<th>Type</th>
 			<th hidden >Assigned Date   <button type="submit" disabled class="btn btn-primary">Intimation</button></th>

 	
         
 		</tr>
 	</thead>
 	<tbody>
 	   
 	    <?php $i=1?>
 	     @if(count($Course)>0)
 		@foreach($Course as $key=>$Course1)
		<tr>
		 <td>{{$i}}</td>
		 <td id="courseid".{{$Course1->course_masters_id}}>{{$Course1->course_name}}<input hidden disabled type="text" value="{{ $schoolid}}_{{ $planidd}}_{{$acyear}}__{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}"></td> 
         <td id="doctype".{{$Course1->doc_types_id}}>{{$Course1->type}}</td>
          <td hidden id="bday".{{$Course1->doc_types_id}}><input disabled type="date" name="data_{{ $schoolid}}_{{ $planidd}}_{{$acyear}}_{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}" value="{{ $schoolid}}_{{ $planidd}}_{{$acyear}}_{{$Course1->course_masters_id}}_{{$Course1->doc_types_id}}"></td>
		</tr>
		<?php $i++?>
		@endforeach
 		@else
         No Record Found.....
      @endif
     
 	</tbody>
 	
 </table>
 </form>
 
 @endif
       
   </div>
@endsection





<!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">-->
<script type="text/javascript"  src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>



@section('footer')
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
 <script type="text/javascript">
 	$(document).ready(function(){
 		$('#courselistid').DataTable();
 	});

//   function myfuntemp(arg) {
//       var ad=$(arg).attr('id');
//       var ak=ad.split('-');
//       // alert('val = '+ak[1]);
//       if(confirm("Do you really want to delete this."))
//          window.location.href='{{url("/schooldel")}}/'+btoa(ak[1]);
//          // alert("yes");
//   }


function intimation(schoolid)
{
    alert("ok"+schoolid);
}


 </script>

 


@endsection