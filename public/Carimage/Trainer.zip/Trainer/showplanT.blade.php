 @extends('layouts.school')
 @section('content')
            <div class="content-heading">
               <div><h2>{{$schoolname->school_name}}</h2> 
                  <small data-localize="dashboard.WELCOME"></small>
               </div>
               <style>https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css</style>
                   <style>https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css</style>
               <!-- START Language list-->
               <!-- <div class="ml-auto">
                  <div class="btn-group">
                     <a href="{{url('agentreg')}}" class="btn btn-warning">Create Agent</a>
                     <button class="btn btn-secondary dropdown-toggle dropdown-toggle-nocaret" type="button" data-toggle="dropdown">English</button>
                     <div class="dropdown-menu dropdown-menu-right-forced animated fadeInUpShort" role="menu"><a class="dropdown-item" href="#" data-set-lang="en">English</a><a class="dropdown-item" href="#" data-set-lang="es">Spanish</a>
                     </div>
                  </div>
               </div> -->
               <!-- END Language list-->
            </div>

            @if($errors->any())
               @foreach($errors->all() as $err)
                  <div class="alert alert-danger">{{$err}}</div>
               @endforeach
            @endif
            @if(session()->has('success'))
               <div class="alert alert-info">{{session()->get('success')}}</div>
            @endif

       <div class="col-md-12">
           
           <div class="text-right">
                           
                           <button type="button" onclick="goBack()" class="btn btn-info">Go Back</button>

<script>
function goBack() {
  window.history.back();
}
</script>
               </div>
 
               <P2>Plan List</p2>
 
      
   </div>

   <br/>
   <div class="col-md-12">
    
    <table class="table table-striped table-bordered" id="planlistid">
 	<thead>
 		<tr>
 		   
 			<th>#</th>
         
 			<th>Plan Name</th>
 			<th>Academic Year</th>
 			<th>Total Participants</th>
 			<th>Date Created</th>
 			<th>View Course</th>
         
 		</tr>
 	</thead>
 	<tbody>
 	    <?php $i=1?>
 	     @if(count($planperschool)>0)
 		@foreach($planperschool as $key=>$planperschool1)
 		
 	   <?php $plansch=base64_encode($planperschool1->plan.",".$schoolid.",".$planperschool1->year)?>
		<tr>
		 <td>{{$i}}</td>
		 <td><a href="{{url('viewcourseinPlan')}}/{{$plansch}}" class="btn btn-warning">{{$planperschool1->name}}</a></td> 
         <td>{{$planperschool1->year}}</td>
          <td><a href="{{url('viewstudentlist')}}/{{$plansch}}" class="btn btn-warning">{{$planperschool1->counts}}</a></td>
         <td>{{$planperschool1->created_at}} </td>
         <td><a href="{{url('viewcourseT')}}/{{$plansch}}" class="btn btn-warning">View Course</a></td>
        
		</tr>
		<?php $i++?>
		@endforeach
 		@else
         No Record Found.....
      @endif
 	</tbody>
 </table>
       
   </div>
@endsection

@section('header')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<script type="text/javascript"  src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<!--<script type="text/javascript" src="https://https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>-->
@endsection

@section('footer')
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
 <script type="text/javascript">
 	$(document).ready(function(){
 		$('#planlistid').DataTable();
 	});

//   function myfuntemp(arg) {
//       var ad=$(arg).attr('id');
//       var ak=ad.split('-');
//       // alert('val = '+ak[1]);
//       if(confirm("Do you really want to delete this."))
//          window.location.href='{{url("/schooldel")}}/'+btoa(ak[1]);
//          // alert("yes");
//   }
 </script>
@endsection